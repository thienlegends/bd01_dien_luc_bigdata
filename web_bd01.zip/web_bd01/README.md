# Web giám sát & dự báo phụ tải điện (FastAPI + Jinja2 + Chart.js)

## Chạy thử ngay bằng dữ liệu giả lập (chưa cần Spark/Delta)
```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python3 tao_du_lieu_demo.py                       # tạo cache/ giả lập
GHI_DELTA_CMD=off uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Mở `http://<máy>:8000`. `GHI_DELTA_CMD=off` tắt bước ghi Delta (chỉ lưu SQLite) khi chưa có Spark.
Trang Quản trị cần Airflow: nếu chưa có sẽ báo lỗi 502 (bình thường).

## Dùng dữ liệu thật
1. Trên cụm: chạy `spark_jobs/cap_nhat_cache_web.py` (xuất gold/silver ra `<lakehouse>/cache_web/` dạng Parquet).
2. Trên máy chạy web: `scripts/dong_bo_cache.sh` (kéo về `cache/`). Cần có lệnh `hdfs` trên máy đó.
3. Bước 1 và 2 chính là task `cap_nhat_cache_web` cuối DAG 1, ví dụ:
   `SparkSubmitOperator(cap_nhat_cache_web.py)` → `BashOperator("bash /đường/dẫn/scripts/dong_bo_cache.sh")`.

## Ghi ngược Delta (màn hình Xử lý cảnh báo)
Bấm nút → web lưu ngay vào SQLite (giao diện đổi trạng thái tức thì) → chạy nền `spark-submit spark_jobs/ghi_xac_nhan_delta.py`
→ append `silver.xac_nhan_canh_bao` và MERGE `gold.canh_bao_bat_thuong`. Mất khoảng 20–60 giây.
Máy chạy web cần có `spark-submit` và truy cập được cụm Spark/HDFS.

## Biến môi trường
| Biến | Mặc định |
|---|---|
| `CACHE_DIR` | `./cache` |
| `AIRFLOW_URL` / `AIRFLOW_USER` / `AIRFLOW_PASS` | `http://master:8081` / `admin` / `admin` |
| `SPARK_MASTER` | `spark://master:7077` |
| `DELTA_PKG` | `io.delta:delta-spark_2.12:3.2.0` (đổi cho khớp Spark) |
| `LAKEHOUSE` | `hdfs://master:9000/lakehouse/bd01_dien_luc` |
| `GHI_DELTA_CMD` | `off` để tắt; hoặc tự đặt lệnh, dùng `{json}` làm chỗ chèn dữ liệu |

Airflow cần bật basic auth cho REST API (`auth_backends = airflow.api.auth.backend.basic_auth`).
Chart.js tải từ CDN; máy không có Internet thì tải `chart.umd.min.js` (v4.4.1) đặt vào `app/static/vendor/`.

## Đối chiếu đặc tả đề
| Yêu cầu | Nơi thực hiện |
|---|---|
| GET /api/phu-tai, /api/du-bao | `app/main.py` |
| GET /api/canh-bao, /api/khach-hang/{id}/tieu-thu | `app/main.py`, `app/db.py` |
| POST /api/canh-bao/{id}/ketluan (ghi ngược + MERGE) | `app/main.py` + `spark_jobs/ghi_xac_nhan_delta.py` |
| GET /api/timetravel?ngay=&phien_ban= | `app/db.py: timetravel` (so dự báo theo `silver_version`) |
| POST /api/dag/{dag_id}/trigger | `app/airflow_client.py` |
| Phản hồi < 3 giây, không query Delta trực tiếp | DuckDB đọc Parquet cache |
