# Các chỉnh sửa cho Web BD01

1. Đồng bộ cấu hình mặc định với cụm: Spark Master `10.94.39.158:7077`, Scala 2.13, Delta `4.4.1`.
2. Job cache ưu tiên `gold/phu_tai_15p`, hỗ trợ fallback `gold/load_15min` và ánh xạ schema `reading_timestamp/total_load`.
3. Dự báo 24 giờ chỉ lấy từ `gold/du_bao_phu_tai`; không đánh tráo bảng dự báo lịch sử `gold/load_forecast_predictions`.
4. Khi Gold dự báo hoặc cảnh báo chưa được tạo, job xuất Parquet rỗng theo schema chuẩn để Website không lỗi; giao diện không sinh dữ liệu giả.
5. Job cache hỗ trợ schema Kafka `meter_id/reading_timestamp/load_kw/ingested_at` trong `silver/doc_so`.
6. Ghi kết luận cảnh báo kiểm tra bảng Gold tồn tại trước khi MERGE.
7. Thêm `scripts/chay_web.sh` để chạy web với các biến môi trường mặc định của cụm BD01.

Lưu ý: chức năng dự báo tương lai và cảnh báo thật chỉ có dữ liệu khi các bảng Gold tương ứng được pipeline tạo ra.
