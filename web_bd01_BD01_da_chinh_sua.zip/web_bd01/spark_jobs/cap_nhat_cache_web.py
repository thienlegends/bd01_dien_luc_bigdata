#!/usr/bin/env python3
"""
Xuất dữ liệu Lakehouse thành Parquet cache cho FastAPI/DuckDB.
Web không đọc trực tiếp Delta. Tương thích cấu trúc Gold hiện có của BD01:
  - gold/phu_tai_15p (ưu tiên), fallback gold/load_15min
  - gold/du_bao_phu_tai (dự báo 96 bước/24 giờ)
  - gold/canh_bao_bat_thuong
  - silver/doc_so (dữ liệu công tơ Kafka)
Bảng dự báo/cảnh báo chưa được tạo thì xuất Parquet rỗng đúng schema;
giao diện sẽ báo chưa có dữ liệu, không tự tạo số liệu giả.
"""
import argparse
from pyspark.sql import SparkSession, functions as F, types as T
from delta.tables import DeltaTable

def delta_exists(spark, path):
    try:
        return DeltaTable.isDeltaTable(spark, path)
    except Exception:
        return False

def read_first(spark, root, candidates):
    for rel in candidates:
        path = f"{root}/{rel}"
        if delta_exists(spark, path):
            print(f"[CACHE] Đọc {path}")
            return spark.read.format("delta").load(path), rel
    return None, None

def ensure_col(df, target, candidates, dtype=None, default=None):
    if target in df.columns:
        return df
    found = next((c for c in candidates if c in df.columns), None)
    if found:
        return df.withColumnRenamed(found, target)
    return df.withColumn(target, F.lit(default).cast(dtype) if dtype else F.lit(default))

def write_parquet(df, root, name):
    path = f"{root}/cache_web/{name}"
    (df.coalesce(1).write.mode("overwrite").parquet(path))
    print(f"[CACHE] {name}: {df.count():,} dòng -> {path}")

def empty_df(spark, fields):
    return spark.createDataFrame([], T.StructType(fields))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--goc", default="hdfs://master:9000/lakehouse/bd01_dien_luc")
    ap.add_argument("--so-ngay", type=int, default=60)
    ap.add_argument("--so-ngay-tieu-thu", type=int, default=28)
    a = ap.parse_args()

    spark = (SparkSession.builder.appName("bd01_cap_nhat_cache_web")
             .config("spark.sql.session.timeZone", "Asia/Ho_Chi_Minh")
             .getOrCreate())
    spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite", "CORRECTED")

    # Gold phụ tải: schema phu_tai_15p hoặc load_15min.
    pt, pt_source = read_first(spark, a.goc, ["gold/phu_tai_15p", "gold/load_15min"])
    if pt is None:
        raise RuntimeError("Không tìm thấy gold/phu_tai_15p hoặc gold/load_15min trên HDFS.")
    pt = ensure_col(pt, "thoi_diem", ["reading_timestamp", "timestamp"], "timestamp")
    pt = ensure_col(pt, "tong_cong_suat_kw", ["total_load", "load_kw", "actual_load"], "double")
    pt = ensure_col(pt, "so_khach_hang_co_du_lieu", ["meter_count"], "long", 0)
    pt = ensure_col(pt, "ty_le_noi_suy", ["interpolation_rate"], "double", 0.0)
    pt = pt.withColumn("thoi_diem", F.to_timestamp("thoi_diem"))
    mx = pt.agg(F.max("thoi_diem").alias("mx")).first()["mx"]
    if mx is None:
        raise RuntimeError(f"{pt_source} tồn tại nhưng không có mốc thời gian.")
    pt_out = (pt.filter(F.col("thoi_diem") >= F.expr(f"timestamp'{mx}'") - F.expr(f"INTERVAL {max(1, a.so_ngay)} DAYS"))
              .select("thoi_diem", "tong_cong_suat_kw", "so_khach_hang_co_du_lieu", "ty_le_noi_suy"))
    write_parquet(pt_out, a.goc, "phu_tai_15p")

    # Dự báo 24h: chỉ lấy bảng canonical; bảng load_forecast_predictions cũ là
    # dự báo lịch sử (reading_timestamp/actual_load/predicted_load), không giả làm forecast tương lai.
    db, db_source = read_first(spark, a.goc, ["gold/du_bao_phu_tai"])
    forecast_schema = [
        T.StructField("thoi_diem_du_bao", T.TimestampType(), True),
        T.StructField("thoi_diem_muc_tieu", T.TimestampType(), True),
        T.StructField("buoc", T.IntegerType(), True),
        T.StructField("gia_tri_du_bao", T.DoubleType(), True),
        T.StructField("can_duoi", T.DoubleType(), True),
        T.StructField("can_tren", T.DoubleType(), True),
        T.StructField("phien_ban_mo_hinh", T.StringType(), True),
        T.StructField("silver_version", T.LongType(), True),
    ]
    if db is None:
        print("[CACHE][WARN] Chưa có gold/du_bao_phu_tai; tạo cache rỗng, không dùng dự báo lịch sử thay thế.")
        db = empty_df(spark, forecast_schema)
    else:
        db = ensure_col(db, "thoi_diem_du_bao", ["forecast_created_at", "prediction_time"], "timestamp")
        db = ensure_col(db, "thoi_diem_muc_tieu", ["target_timestamp", "reading_timestamp"], "timestamp")
        db = ensure_col(db, "buoc", ["step", "horizon_step"], "int")
        db = ensure_col(db, "gia_tri_du_bao", ["predicted_load", "prediction"], "double")
        db = ensure_col(db, "can_duoi", ["lower_bound"], "double")
        db = ensure_col(db, "can_tren", ["upper_bound"], "double")
        db = ensure_col(db, "phien_ban_mo_hinh", ["model_version"], "string", "unknown")
        db = ensure_col(db, "silver_version", ["source_silver_version"], "long")
        db = db.select(*[f.name for f in forecast_schema])
        db = db.filter(F.col("thoi_diem_muc_tieu") >= F.expr(f"timestamp'{mx}'") - F.expr(f"INTERVAL {max(1, a.so_ngay)} DAYS"))
    write_parquet(db, a.goc, "du_bao_phu_tai")

    # Cảnh báo: bảng Gold chưa có thì tạo cache rỗng để web vẫn chạy.
    cb, _ = read_first(spark, a.goc, ["gold/canh_bao_bat_thuong"])
    alert_schema = [
        T.StructField("ma_canh_bao", T.StringType(), True),
        T.StructField("ma_khach_hang", T.StringType(), True),
        T.StructField("ngay_phat_hien", T.DateType(), True),
        T.StructField("loai", T.StringType(), True),
        T.StructField("diem_bat_thuong", T.DoubleType(), True),
        T.StructField("bang_chung", T.StringType(), True),
        T.StructField("trang_thai", T.StringType(), True),
    ]
    if cb is None:
        print("[CACHE][WARN] Chưa có gold/canh_bao_bat_thuong; tạo cache cảnh báo rỗng.")
        cb = empty_df(spark, alert_schema)
    else:
        cb = ensure_col(cb, "ma_canh_bao", ["alert_id"], "string")
        cb = ensure_col(cb, "ma_khach_hang", ["meter_id", "customer_id"], "string")
        cb = ensure_col(cb, "ngay_phat_hien", ["alert_date", "reading_date"], "date")
        cb = ensure_col(cb, "loai", ["alert_type"], "string")
        cb = ensure_col(cb, "diem_bat_thuong", ["anomaly_score", "score"], "double")
        cb = ensure_col(cb, "bang_chung", ["evidence"], "string", "{}")
        cb = ensure_col(cb, "trang_thai", ["status"], "string", "moi")
        cb = cb.select(*[f.name for f in alert_schema])
    write_parquet(cb, a.goc, "canh_bao_bat_thuong")

    # Silver doc_so: hỗ trợ cả schema Kafka hiện tại lẫn schema long-form của pipeline cũ.
    sv, _ = read_first(spark, a.goc, ["silver/doc_so"])
    if sv is None:
        print("[CACHE][WARN] Chưa có silver/doc_so; tạo cache tiêu thụ/dữ liệu trễ rỗng.")
        sv = spark.createDataFrame([], "ma_khach_hang string, thoi_diem_doc timestamp, cong_suat_kw double, chat_luong string, do_tre_phut double, co_hieu_chinh boolean")
    else:
        sv = ensure_col(sv, "ma_khach_hang", ["meter_id", "customer_id"], "string")
        sv = ensure_col(sv, "thoi_diem_doc", ["reading_timestamp", "timestamp"], "timestamp")
        sv = ensure_col(sv, "cong_suat_kw", ["load_kw", "power_kw"], "double")
        sv = ensure_col(sv, "chat_luong", ["quality"], "string", "tot")
        sv = ensure_col(sv, "ingested_at", ["ingestion_timestamp"], "timestamp")
        if "do_tre_phut" not in sv.columns:
            if "ingested_at" in sv.columns:
                sv = sv.withColumn("do_tre_phut",
                    (F.col("ingested_at").cast("long") - F.col("thoi_diem_doc").cast("long")) / 60.0)
            else:
                sv = sv.withColumn("do_tre_phut", F.lit(0.0))
        sv = ensure_col(sv, "co_hieu_chinh", [], "boolean", False)
        sv = sv.withColumn("thoi_diem_doc", F.to_timestamp("thoi_diem_doc"))
        sv = sv.withColumn("ngay", F.to_date("thoi_diem_doc"))

    mx_sv = sv.agg(F.max("thoi_diem_doc").alias("mx")).first()["mx"]
    if mx_sv is not None:
        tieu_thu = (sv.filter(F.col("thoi_diem_doc") >= F.expr(f"timestamp'{mx_sv}'") - F.expr(f"INTERVAL {max(1, a.so_ngay_tieu_thu)} DAYS"))
                    .select("ma_khach_hang", "thoi_diem_doc", "cong_suat_kw", "chat_luong"))
        tre = (sv.withColumn("ngay", F.to_date("thoi_diem_doc"))
               .filter(F.col("thoi_diem_doc") >= F.expr(f"timestamp'{mx_sv}'") - F.expr(f"INTERVAL {max(1, a.so_ngay)} DAYS"))
               .groupBy("ngay")
               .agg(F.count("*").alias("tong_ban_ghi"),
                    F.sum(F.when(F.col("do_tre_phut") >= 60, 1).otherwise(0)).alias("so_ban_ghi_tre"),
                    F.sum(F.col("co_hieu_chinh").cast("int")).alias("so_hieu_chinh")))
    else:
        tieu_thu = spark.createDataFrame([], "ma_khach_hang string, thoi_diem_doc timestamp, cong_suat_kw double, chat_luong string")
        tre = spark.createDataFrame([], "ngay date, tong_ban_ghi long, so_ban_ghi_tre long, so_hieu_chinh long")
    write_parquet(tieu_thu, a.goc, "tieu_thu")
    write_parquet(tre, a.goc, "du_lieu_tre")
    spark.stop()

if __name__ == "__main__":
    main()
