#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export CACHE_DIR="${CACHE_DIR:-$ROOT/cache}"
export DATA_DIR="${DATA_DIR:-$ROOT/data}"
export AIRFLOW_URL="${AIRFLOW_URL:-http://10.94.39.158:8081}"
export AIRFLOW_API="${AIRFLOW_API:-/api/v1}"
export SPARK_MASTER="${SPARK_MASTER:-spark://10.94.39.158:7077}"
export DELTA_PKG="${DELTA_PKG:-io.delta:delta-spark_2.13:4.4.1}"
export LAKEHOUSE="${LAKEHOUSE:-hdfs://master:9000/lakehouse/bd01_dien_luc}"
exec uvicorn app.main:app --host 0.0.0.0 --port 8000
