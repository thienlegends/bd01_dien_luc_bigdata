"""Smoke test hạ tầng: Spark 3.5.1 (connector spark-sql-kafka-0-10) <-> broker Kafka 3.6.x.

KHÔNG phải job streaming của đề tài. Chỉ chứng minh (mục V08): connector + kafka-clients 3.4.x kéo về bởi
Ivy nói chuyện được với broker 3.6, theo cả hai chiều (ghi batch rồi đọc batch).

Đầu vào : biến môi trường KAFKA_BOOTSTRAP_INTERNAL (mặc định kafka:29092)
Đầu ra  : JSON tóm tắt trên stdout; exit 0 nếu đạt. Ghi 1 tin nhắn vào topic riêng `bd01_smoke_kafka`
          (không đụng tới topic `meter_readings`). Broker đặt auto.create.topics=false nên topic
          smoke phải được tạo trước bằng lệnh kafka-topics ở mục "Chạy" bên dưới.
Phụ thuộc: conf/spark-defaults.conf (spark.jars.packages có spark-sql-kafka), broker `kafka` đang chạy.

Chạy:
  DC="docker compose --env-file conf/.env"
  $DC exec -T kafka kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists \
        --topic bd01_smoke_kafka --partitions 1 --replication-factor 1
  $DC exec spark-client spark-submit --total-executor-cores 2 /opt/bd01/tests/infra/smoke_kafka_spark.py
"""
import json
import os
import sys
import time

from pyspark.sql import SparkSession

BOOTSTRAP = os.environ.get("KAFKA_BOOTSTRAP_INTERNAL", "kafka:29092")
TOPIC = "bd01_smoke_kafka"


def main():
    spark = SparkSession.builder.appName("bd01_smoke_kafka_spark").getOrCreate()
    marker = f"smoke_{int(time.time())}"

    (spark.createDataFrame([(marker, marker)], "key string, value string")
          .write.format("kafka")
          .option("kafka.bootstrap.servers", BOOTSTRAP)
          .option("topic", TOPIC)
          .save())

    back = (spark.read.format("kafka")
            .option("kafka.bootstrap.servers", BOOTSTRAP)
            .option("subscribe", TOPIC)
            .option("startingOffsets", "earliest")
            .load()
            .selectExpr("CAST(value AS STRING) AS value")
            .where(f"value = '{marker}'"))
    found = back.count()

    kafka_jars = [p for p in spark.sparkContext.getConf().get("spark.jars.packages", "").split(",") if "kafka" in p]
    result = {"bootstrap": BOOTSTRAP, "topic": TOPIC, "marker": marker, "found": found,
              "spark_version": spark.version, "kafka_packages": kafka_jars, "all_ok": found == 1}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    spark.stop()
    return 0 if result["all_ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
