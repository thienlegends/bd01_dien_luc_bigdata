#!/usr/bin/env python3
"""Kiểm tra TĨNH cấu hình hạ tầng (không cần Docker daemon, không cần Spark).

Kiểm tra gì (đây là kiểm tra cấu hình, KHÔNG thay cho kiểm chứng chạy thực tế V01..V12):
  S01 .env.example: bí mật chỉ là CHANGE_ME*; mọi biến ${VAR} trong compose đều có trong .env.example
  S02 Đường dẫn lưu trữ: LAKEHOUSE_ROOT/warehouse/eventlog/defaultFS đều hdfs://, không có file: ở conf/
  S03 Phiên bản: họ phiên bản đúng yêu cầu A.3; spark-defaults, Dockerfile, compose mặc định khớp .env.example
  S04 docker compose config giải được (nếu có docker CLI); cổng publish chỉ bind 127.0.0.1;
      không volume nào chứa bảng Delta (lakehouse/delta)
  S05 XML hợp lệ, replication=1; script bash qua `bash -n`; .gitignore chặn conf/.env
  S06 Không có mật khẩu/khóa thật nằm rải rác trong file nguồn
  S07 (tuỳ chọn --env conf/.env) conf/.env không còn CHANGE_ME

Chạy:  python3 tests/infra/static_checks.py            (từ thư mục gốc repo)
       python3 tests/infra/static_checks.py --env conf/.env
Thoát 0 nếu tất cả đạt, 1 nếu có lỗi.
"""
import json
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ENV_EXAMPLE = ROOT / "conf" / ".env.example"
COMPOSE = ROOT / "docker-compose.yml"
SPARK_CONF = ROOT / "conf" / "spark-defaults.conf"

failures = []
passes = []


def check(code, cond, msg):
    (passes if cond else failures).append(f"{code} {msg}")
    print(f"[{'PASS' if cond else 'FAIL'}] {code} {msg}")


def parse_env(path):
    env = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        env[k.strip()] = v.strip()
    return env


env = parse_env(ENV_EXAMPLE)
compose_text = COMPOSE.read_text(encoding="utf-8")
spark_conf_text = SPARK_CONF.read_text(encoding="utf-8")

# ---------------------------------------------------------------- S01
SECRET_NAME = re.compile(r"(PASSWORD|SECRET|FERNET|TOKEN|_KEY)", re.I)
secret_keys = [k for k in env if SECRET_NAME.search(k)] + ["KAFKA_CLUSTER_ID"]
bad = [k for k in set(secret_keys) if not env.get(k, "").startswith("CHANGE_ME")]
check("S01a", not bad, f"mọi bí mật trong .env.example là CHANGE_ME* (vi phạm: {bad})")

used = set(re.findall(r"\$\{([A-Z][A-Z0-9_]*)", compose_text))
missing = sorted(used - set(env))
check("S01b", not missing, f"mọi biến ${{VAR}} trong compose đều có trong .env.example (thiếu: {missing})")

# ---------------------------------------------------------------- S02
for k in ("LAKEHOUSE_ROOT", "SPARK_EVENTLOG_DIR", "SPARK_WAREHOUSE_DIR", "HDFS_BASE_URI"):
    check("S02a", env.get(k, "").startswith("hdfs://"), f"{k} bắt đầu bằng hdfs:// ({env.get(k)})")
check("S02b", env.get("LAKEHOUSE_ROOT", "").endswith("/lakehouse/bd01_dien_luc"),
      "LAKEHOUSE_ROOT kết thúc bằng /lakehouse/bd01_dien_luc (A.4)")

conf_files = [p for p in (ROOT / "conf").rglob("*") if p.is_file() and p.name != ".env"]
offenders = []
for p in conf_files + [COMPOSE]:
    for n, line in enumerate(p.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
        if re.search(r"\bfile:/|\blocal\[", line) and not line.lstrip().startswith(("#", "<!--")):
            # file:///data/hdfs/... trong hdfs-site.xml là thư mục lưu block CỦA HDFS (hợp lệ), loại trừ
            if p.name == "hdfs-site.xml":
                continue
            offenders.append(f"{p.relative_to(ROOT)}:{n}")
check("S02c", not offenders, f"không có file:/ hay local[*] trong cấu hình (vi phạm: {offenders})")
check("S02d", re.search(r"^spark\.hadoop\.fs\.defaultFS\s+hdfs://", spark_conf_text, re.M) is not None,
      "spark-defaults.conf đặt fs.defaultFS = hdfs://")
check("S02e", re.search(r"^spark\.sql\.warehouse\.dir\s+hdfs://", spark_conf_text, re.M) is not None,
      "spark.sql.warehouse.dir = hdfs://")

# ---------------------------------------------------------------- S03
def family(key, prefix):
    check("S03a", env.get(key, "").startswith(prefix), f"{key}={env.get(key)} thuộc họ {prefix}x")

family("HADOOP_VERSION", "3.3.")
family("SPARK_VERSION", "3.5.")
family("DELTA_VERSION", "3.1.")
family("KAFKA_CP_VERSION", "7.6.")      # Confluent 7.6.x = Apache Kafka 3.6.x
family("AIRFLOW_VERSION", "2.9.")
check("S03b", env.get("SCALA_BINARY_VERSION") == "2.12", "Scala 2.12 (artifact delta-spark_2.12 / spark-sql-kafka-0-10_2.12)")

pk = re.search(r"^spark\.jars\.packages\s+(\S+)", spark_conf_text, re.M)
packages = pk.group(1).split(",") if pk else []
want_delta = f"io.delta:delta-spark_{env['SCALA_BINARY_VERSION']}:{env['DELTA_VERSION']}"
want_kafka = f"org.apache.spark:spark-sql-kafka-0-10_{env['SCALA_BINARY_VERSION']}:{env['SPARK_VERSION']}"
check("S03c", want_delta in packages,
      f"spark-defaults.conf nạp {want_delta} (đang là {packages})")
check("S03f", want_kafka in packages,
      f"spark-defaults.conf nạp {want_kafka} — phiên bản connector Kafka phải == SPARK_VERSION (đang là {packages})")

for df in (ROOT / "conf" / "docker").rglob("Dockerfile"):
    for arg, val in re.findall(r"^ARG\s+([A-Z_]+)=(\S+)", df.read_text(encoding="utf-8"), re.M):
        if arg in env:
            check("S03d", env[arg] == val, f"{df.relative_to(ROOT)}: ARG {arg} mặc định {val} == .env.example {env[arg]}")

for var, default in re.findall(r"\$\{([A-Z_]+):-([^}]*)\}", compose_text):
    if var in ("HADOOP_VERSION", "SPARK_VERSION", "DELTA_VERSION", "KAFKA_CP_VERSION", "AIRFLOW_VERSION",
               "SCALA_BINARY_VERSION", "JAVA_IMAGE_TAG", "JAVA_MAJOR", "AIRFLOW_PYTHON_VERSION",
               "AIRFLOW_SPARK_PROVIDER_VERSION", "POSTGRES_VERSION"):
        check("S03e", env.get(var) == default, f"compose mặc định {var}:-{default} == .env.example {env.get(var)}")

# ---------------------------------------------------------------- S04
if shutil.which("docker"):
    r = subprocess.run(["docker", "compose", "--env-file", str(ENV_EXAMPLE), "-f", str(COMPOSE),
                        "--profile", "yarn", "--profile", "history", "config", "--format", "json"],
                       capture_output=True, text=True, cwd=ROOT)
    check("S04a", r.returncode == 0, "docker compose config giải được (profile yarn+history)"
          + ("" if r.returncode == 0 else f": {r.stderr.strip()[:300]}"))
    if r.returncode == 0:
        cfg = json.loads(r.stdout)
        services = cfg["services"]
        need = {"namenode", "datanode", "hdfs-init", "kafka", "kafka-init", "spark-master", "spark-worker-1",
                "spark-worker-2", "spark-client", "postgres", "airflow-init", "airflow-webserver",
                "airflow-scheduler", "resourcemanager", "nodemanager", "spark-history", "mailpit"}
        check("S04b", need <= set(services), f"đủ service cần thiết (thiếu: {sorted(need - set(services))})")
        badports = []
        for name, svc in services.items():
            for p in svc.get("ports", []):
                if p.get("host_ip") != "127.0.0.1":
                    badports.append(f"{name}:{p.get('published')}")
        check("S04c", not badports, f"mọi cổng publish chỉ bind 127.0.0.1 (vi phạm: {badports})")
        delta_vol = []
        for name, svc in services.items():
            for v in svc.get("volumes", []):
                tgt = v.get("target", "")
                if re.search(r"lakehouse|delta|bronze|silver|gold", tgt, re.I):
                    delta_vol.append(f"{name}:{tgt}")
        check("S04d", not delta_vol, f"không volume nào chứa bảng Delta (vi phạm: {delta_vol})")
        spark_conn = services["airflow-scheduler"]["environment"].get("AIRFLOW_CONN_SPARK_DEFAULT", "")
        check("S04e", '"spark://spark-master"' in spark_conn, "connection spark_default có host spark://spark-master")
        total = 0
        def to_mb(x):
            x = str(x)
            n = float(re.match(r"[\d.]+", x).group())
            return n * (1024 if x.lower().endswith("g") else 1) if re.search(r"[gm]$", x.lower()) else n / 1048576
        default_services = [s for s, v in services.items() if not v.get("profiles")]
        for s in default_services:
            ml = services[s].get("mem_limit")
            if ml:
                total += to_mb(ml) if not str(ml).isdigit() else int(ml) / 1048576
        print(f"[INFO] Tổng mem_limit (trần) các service mặc định: {total/1024:.1f} GB "
              "— đây là TRẦN, không phải mức dùng thực; đo bằng `docker stats` (xem docs/MEMORY_BUDGET.md)")
else:
    print("[SKIP] S04 docker CLI không có — bỏ qua giải compose")

# ---------------------------------------------------------------- S05
for p in sorted((ROOT / "conf").glob("*.xml")):
    try:
        ET.parse(p)
        check("S05a", True, f"{p.name} là XML hợp lệ")
    except ET.ParseError as e:
        check("S05a", False, f"{p.name} XML lỗi: {e}")

hdfs = ET.parse(ROOT / "conf" / "hdfs-site.xml").getroot()
props = {pp.findtext("name"): pp.findtext("value") for pp in hdfs.findall("property")}
check("S05b", props.get("dfs.replication") == "1", "dfs.replication = 1 (chỉ 1 DataNode)")
core = ET.parse(ROOT / "conf" / "core-site.xml").getroot()
cprops = {pp.findtext("name"): pp.findtext("value") for pp in core.findall("property")}
check("S05c", (cprops.get("fs.defaultFS") or "").startswith("hdfs://"), "core-site.xml fs.defaultFS = hdfs://")

for sh in list((ROOT / "conf" / "scripts").glob("*.sh")) + [ROOT / "conf" / "docker" / "hadoop" / "entrypoint.sh"]:
    r = subprocess.run(["bash", "-n", str(sh)], capture_output=True, text=True)
    check("S05d", r.returncode == 0, f"bash -n {sh.relative_to(ROOT)}" + ("" if r.returncode == 0 else f": {r.stderr.strip()}"))

gi = (ROOT / ".gitignore").read_text(encoding="utf-8")
check("S05e", "conf/.env" in gi, ".gitignore chặn conf/.env")

# ---------------------------------------------------------------- S06
assign = re.compile(r"(PASSWORD|SECRET|FERNET_KEY|TOKEN)\w*\s*[:=]\s*['\"]?([^\s'\"]+)", re.I)
leaks = []
for p in ROOT.rglob("*"):
    if not p.is_file() or p.suffix in (".pyc",) or ".git" in p.parts or p.name == ".env":
        continue
    if p.resolve() == Path(__file__).resolve():
        continue
    try:
        text = p.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        continue
    for n, line in enumerate(text.splitlines(), 1):
        line = re.sub(r"\$\{[^}]*\}", "${}", line)  # bỏ phần nội suy biến, chỉ xét giá trị viết cứng
        for _, val in assign.findall(line):
            if not (val.startswith(("CHANGE_ME", "${", "$", "<", "...", "(", "{")) or val.lower() in ("none", "true", "false", "")):
                leaks.append(f"{p.relative_to(ROOT)}:{n}")
check("S06", not leaks, f"không có mật khẩu/khóa thật rải rác (nghi vấn: {leaks[:10]})")

# ---------------------------------------------------------------- S07
if "--env" in sys.argv:
    real = parse_env(ROOT / sys.argv[sys.argv.index("--env") + 1])
    left = [k for k, v in real.items() if v.startswith("CHANGE_ME")]
    check("S07", not left, f"conf/.env đã thay hết CHANGE_ME (còn: {left})")

print(f"\nTổng kết: {len(passes)} PASS, {len(failures)} FAIL")
sys.exit(1 if failures else 0)
