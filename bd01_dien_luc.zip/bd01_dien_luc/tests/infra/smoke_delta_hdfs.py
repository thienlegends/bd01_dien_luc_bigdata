"""Smoke test hạ tầng: Delta Lake 3.1.x trên Spark 3.5.x GHI VÀO HDFS.

Đây KHÔNG phải pipeline của đề tài — chỉ chứng minh hạ tầng đủ năng lực cho các yêu cầu A.6.2/A.6.3:
  ghi Delta lên HDFS, MERGE INTO, DESCRIBE HISTORY, VERSION AS OF, Change Data Feed, OPTIMIZE (số file
  trước/sau), và xác nhận vị trí bảng bắt đầu bằng hdfs:// (không phải file:).

Đầu vào : biến môi trường HDFS_BASE_URI (mặc định hdfs://namenode:8020); tuỳ chọn --keep giữ lại dữ liệu
Đầu ra  : JSON tóm tắt trên stdout (lưu vào docs/evidence/smoke_delta_hdfs.json); exit 0 nếu mọi kiểm tra đạt.
Phụ thuộc: conf/spark-defaults.conf (Delta extension, HDFS), cluster Spark + HDFS đang chạy.

Chạy:
  docker compose --env-file conf/.env exec spark-client \
      spark-submit /opt/bd01/tests/infra/smoke_delta_hdfs.py
"""
import json
import os
import sys
import time

from delta.tables import DeltaTable
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

BASE = os.environ.get("HDFS_BASE_URI", "hdfs://namenode:8020")
KEEP = "--keep" in sys.argv
PATH = f"{BASE}/tmp/bd01_smoke/doc_so_{int(time.time())}"

results = {"path": PATH, "checks": {}}


def check(name, cond, detail=None):
    results["checks"][name] = {"ok": bool(cond), "detail": detail}
    print(f"[{'PASS' if cond else 'FAIL'}] {name}" + (f" — {detail}" if detail is not None else ""))
    return bool(cond)


def num_files(spark):
    return int(DeltaTable.forPath(spark, PATH).detail().select("numFiles").first()[0])


def main():
    # Bảo vệ cứng: nếu đường dẫn không phải HDFS thì dừng ngay, KHÔNG âm thầm ghi local.
    if not PATH.startswith("hdfs://"):
        print(f"LỖI: đường dẫn smoke test '{PATH}' không phải hdfs://", file=sys.stderr)
        return 2

    spark = SparkSession.builder.appName("bd01_smoke_delta_hdfs").getOrCreate()
    results["spark_version"] = spark.version
    results["delta_jars"] = spark.sparkContext.getConf().get("spark.jars.packages", "")
    ok = True

    # 1) Ghi bản đầu + 5 lần append nhỏ để tạo "small files"
    base = (spark.range(0, 1000)
            .select(F.concat(F.lit("KH"), F.col("id").cast("string")).alias("ma_khach_hang"),
                    F.lit("2014-01-01 00:00:00").cast("timestamp").alias("thoi_diem_doc"),
                    (F.col("id") % 50 + 1.0).alias("cong_suat_kw"),
                    F.lit("realtime").alias("nguon")))
    base.write.format("delta").mode("overwrite").save(PATH)
    # Change Data Feed bật bằng thuộc tính bảng (mục 1.7): chỉ ghi nhận thay đổi từ phiên bản này trở đi
    spark.sql(f"ALTER TABLE delta.`{PATH}` SET TBLPROPERTIES (delta.enableChangeDataFeed = true)")
    for i in range(5):
        (spark.createDataFrame([(f"KH_new{i}", 1.0 + i, "realtime")],
                               "ma_khach_hang string, cong_suat_kw double, nguon string")
              .withColumn("thoi_diem_doc", F.lit("2014-01-01 00:00:00").cast("timestamp"))
              .select("ma_khach_hang", "thoi_diem_doc", "cong_suat_kw", "nguon")
              .write.format("delta").mode("append").save(PATH))

    dt = DeltaTable.forPath(spark, PATH)
    location = dt.detail().select("location").first()[0]
    ok &= check("vị trí bảng bắt đầu bằng hdfs://", location.startswith("hdfs://"), location)
    ok &= check("không có scheme file:", "file:" not in location)

    # 2) MERGE INTO (bản ghi hieu_chinh ghi đè — mô phỏng mục 1.7)
    v_before_merge = dt.history(1).select("version").first()[0]
    corrections = (spark.createDataFrame([("KH7", 999.0, "hieu_chinh")],
                                         "ma_khach_hang string, cong_suat_kw double, nguon string")
                   .withColumn("thoi_diem_doc", F.lit("2014-01-01 00:00:00").cast("timestamp")))
    (dt.alias("t").merge(corrections.alias("s"),
                         "t.ma_khach_hang = s.ma_khach_hang AND t.thoi_diem_doc = s.thoi_diem_doc")
       .whenMatchedUpdate(condition="s.nguon = 'hieu_chinh'",
                          set={"cong_suat_kw": "s.cong_suat_kw", "nguon": "s.nguon"})
       .whenNotMatchedInsertAll().execute())

    # 3) DESCRIBE HISTORY có WRITE và MERGE
    ops = [r[0] for r in dt.history().select("operation").collect()]  # <= vài chục dòng
    ok &= check("DESCRIBE HISTORY có WRITE", "WRITE" in ops, ops)
    ok &= check("DESCRIBE HISTORY có MERGE", "MERGE" in ops, ops)

    # 4) Time travel: VERSION AS OF cho giá trị khác nhau trước/sau MERGE
    old = (spark.read.format("delta").option("versionAsOf", v_before_merge).load(PATH)
           .where("ma_khach_hang = 'KH7'").select("cong_suat_kw").first()[0])
    new = (spark.read.format("delta").load(PATH)
           .where("ma_khach_hang = 'KH7'").select("cong_suat_kw").first()[0])
    ok &= check("VERSION AS OF trả về giá trị khác sau MERGE", old != new, {"truoc": old, "sau": new})

    # 5) Change Data Feed đọc được phần thay đổi
    last_v = dt.history(1).select("version").first()[0]
    cdf = (spark.read.format("delta").option("readChangeFeed", "true")
           .option("startingVersion", last_v).load(PATH))
    change_types = sorted(r[0] for r in cdf.select("_change_type").distinct().collect())
    ok &= check("CDF có update_postimage", "update_postimage" in change_types, change_types)

    # 6) OPTIMIZE: số file trước/sau
    files_before = num_files(spark)
    t0 = time.time()
    DeltaTable.forPath(spark, PATH).optimize().executeCompaction()
    optimize_seconds = round(time.time() - t0, 2)
    files_after = num_files(spark)
    results["optimize"] = {"files_before": files_before, "files_after": files_after,
                           "seconds": optimize_seconds}
    ok &= check("OPTIMIZE giảm số file", files_after < files_before,
                results["optimize"])

    # 7) Dọn dẹp bằng Hadoop FileSystem API (trừ khi --keep)
    if not KEEP:
        jvm = spark._jvm
        fs = jvm.org.apache.hadoop.fs.Path(PATH).getFileSystem(spark._jsc.hadoopConfiguration())
        fs.delete(jvm.org.apache.hadoop.fs.Path(PATH), True)
        results["cleaned_up"] = True

    results["all_ok"] = bool(ok)
    print(json.dumps(results, ensure_ascii=False, indent=2, default=str))
    spark.stop()
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
