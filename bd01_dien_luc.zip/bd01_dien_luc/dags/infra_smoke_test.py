"""DAG kiểm tra hạ tầng (KHÔNG thuộc 3-4 DAG nghiệm thu của đề tài; có thể xóa sau giai đoạn hạ tầng).

Mục đích: chứng minh Airflow 2.9.3 -> SparkSubmitOperator -> Spark Standalone -> Delta -> HDFS chạy thông
(đây là điểm tích hợp rủi ro nhất — mục V10/V11 trong docs/VERSION_COMPATIBILITY.md).

Đầu vào : connection `spark_default` (khai báo bằng AIRFLOW_CONN_SPARK_DEFAULT trong docker-compose.yml)
Đầu ra  : task thành công + log JSON của tests/infra/smoke_delta_hdfs.py trong log Airflow
Phụ thuộc: tests/infra/smoke_delta_hdfs.py (mount tại /opt/bd01/tests), conf/spark-defaults.conf
Kích hoạt thủ công: Airflow UI -> infra_smoke_test -> Trigger (schedule=None).
"""
from datetime import datetime, timedelta

from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator

with DAG(
    dag_id="infra_smoke_test",
    description="Smoke test Airflow -> Spark -> Delta -> HDFS",
    schedule=None,
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=["infra"],
    default_args={"retries": 0, "retry_delay": timedelta(minutes=1)},
) as dag:
    SparkSubmitOperator(
        task_id="smoke_delta_hdfs",
        conn_id="spark_default",
        application="/opt/bd01/tests/infra/smoke_delta_hdfs.py",
        name="bd01_smoke_delta_hdfs",
        # chừa 2 core cho ứng dụng khác (xem docs/MEMORY_BUDGET.md)
        total_executor_cores=2,
        verbose=False,
    )
