# AI_USAGE.md — khai báo sử dụng AI (đề cương A.9)

> Bắt buộc theo A.9: ghi prompt, phần nào do AI sinh, phần nào nhóm sửa. Không khai báo mà bị phát hiện → 0 điểm hạng mục liên quan.
> **Nhóm phải tự điền cột "Nhóm đã sửa/kiểm chứng" sau khi đọc và chạy.**

| Ngày | Giai đoạn | Prompt (tóm tắt) | Phần do AI sinh | Nhóm đã sửa/kiểm chứng |
|---|---|---|---|---|
| 2026-10-11 | Hạ tầng | "Thiết kế cấu trúc repo bd01_dien_luc theo A.5; `.env.example` không mật khẩu thật; docker-compose cho HDFS, Spark, Delta, Kafka, Airflow tương thích; kiểm tra Hadoop 3.3 / Spark 3.5 / Delta 3.1 / Kafka 3.6 / Airflow 2.9; cấu hình 16 GB; README; Delta phải trên HDFS" | `docker-compose.yml`, `conf/**` (env, spark-defaults, XML, Dockerfile, script), `tests/infra/*`, `dags/infra_smoke_test.py`, `README.md`, `docs/*.md` | _(chưa điền — nhóm cần chạy V01–V12 và ghi lại chỗ đã sửa)_ |
