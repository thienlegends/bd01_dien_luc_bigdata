# Ngân sách RAM cho máy 16 GB

> Các con số "ước tính" dưới đây là **dự toán** từ cấu hình heap, chưa đo. Đo thật bằng
> `docker stats --no-stream` sau 10 phút chạy streaming (mục V12 trong `VERSION_COMPATIBILITY.md`).

## 1. Nguyên tắc

1. **Docker phải được cấp ≥ 12 GB** trên Windows (WSL2) / macOS (Docker Desktop). Để lại ≥ 4 GB cho hệ điều hành.
   - Windows: tạo `%UserProfile%\.wslconfig` với `[wsl2]` / `memory=12GB` / `swap=4GB`, rồi `wsl --shutdown`.
   - macOS: Docker Desktop → Settings → Resources → Memory = 12 GB.
   - Linux: không có máy ảo trung gian, dùng trực tiếp RAM máy.
2. Cấu hình Spark theo đề cương (A.3, C.2): **2 executor × 2 core × 2 GB**, driver 2 GB.
   Standalone: 2 worker, mỗi worker 1 executor.
3. Chỉ **2 ứng dụng Spark chạy đồng thời** (mỗi ứng dụng 1 executor, `--total-executor-cores 2`):
   streaming liên tục + 1 job batch. Không chạy huấn luyện ML song song với demo streaming.
4. Profile `yarn` và `history` **tắt mặc định**.

## 2. Bảng dự toán

| Service | Heap/cấu hình | Trần `mem_limit` | Ước tính khi chạy |
|---|---|---|---|
| namenode | 512 MB | 1 GB | ~0,5–0,7 GB |
| datanode | 512 MB | 1 GB | ~0,5–0,7 GB |
| kafka (KRaft) | 512 MB | 1 GB | ~0,6–0,8 GB |
| spark-master | 512 MB | 768 MB | ~0,3 GB |
| spark-worker-1 (daemon + executor 2 GB + overhead 512 MB) | | 3,5 GB | ~0,3 GB nghỉ; ~2,5–3 GB khi có executor |
| spark-worker-2 | | 3,5 GB | như trên |
| spark-client (driver streaming) | `--driver-memory 1g` | 3 GB | ~1,3–1,8 GB khi có job |
| postgres | | 512 MB | ~0,15 GB |
| airflow-webserver | 2 worker | 1,5 GB | ~0,8–1 GB |
| airflow-scheduler (+ driver batch 2 GB) | | 3,5 GB | ~0,7 GB nghỉ; ~2,5–3 GB khi chạy `SparkSubmitOperator` |
| mailpit | | 128 MB | ~0,03 GB |

- **Tổng trần** các service mặc định ≈ 19 GB (do `static_checks.py` tính) — chỉ là trần, **không** phải mức dùng.
- **Ước tính nghỉ** (chưa chạy job): ≈ 4–5 GB.
- **Ước tính đỉnh** (streaming + 1 job batch, 2 executor chạy): ≈ 11–13 GB ⇒ sát giới hạn 12 GB của Docker.
  Nếu bị `OOMKilled`, dùng các cách giảm bên dưới theo thứ tự.

## 3. Cách giảm khi thiếu RAM (theo thứ tự ưu tiên)

1. Không chạy streaming và batch cùng lúc ngoài buổi demo.
2. Hạ `spark.executor.memory` xuống `1g`, `SPARK_WORKER_MEMORY=1g` (sửa `conf/spark-defaults.conf` và `conf/.env`).
3. Hạ `spark.driver.memory` của job nhẹ (`--driver-memory 1g`).
4. Dùng phương án dự phòng của đề cương (mục 1.10): **giảm còn 100 khách hàng**, giữ nguyên logic, và ghi rõ trong báo cáo.
5. Tắt `mailpit` và `spark-history` nếu không dùng.

## 4. Cách đo (lưu làm bằng chứng)

```bash
docker stats --no-stream --format "table {{.Name}}\t{{.MemUsage}}\t{{.MemPerc}}" | tee docs/evidence/v12_docker_stats.txt
for c in $(docker ps -q); do docker inspect -f '{{.Name}} OOMKilled={{.State.OOMKilled}}' $c; done
```
