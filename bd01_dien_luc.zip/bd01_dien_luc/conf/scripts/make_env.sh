#!/usr/bin/env bash
# Tạo conf/.env từ conf/.env.example, thay MỌI giá trị CHANGE_ME_* bằng bí mật ngẫu nhiên.
#   Đầu vào : conf/.env.example
#   Đầu ra  : conf/.env (quyền 600, đã nằm trong .gitignore). Không ghi đè nếu đã tồn tại (dùng --force).
#   Phụ thuộc: python3 (chỉ thư viện chuẩn)
set -euo pipefail

cd "$(dirname "$0")/../.."
SRC="conf/.env.example"
DST="conf/.env"

if [ -f "${DST}" ] && [ "${1:-}" != "--force" ]; then
  echo "conf/.env đã tồn tại — giữ nguyên. Dùng --force để tạo lại (SẼ đổi mật khẩu Postgres/Airflow)." >&2
  exit 0
fi

python3 - "${SRC}" "${DST}" <<'PY'
import base64, os, re, secrets, sys, uuid

src, dst = sys.argv[1], sys.argv[2]

def gen(name: str) -> str:
    if name == "KAFKA_CLUSTER_ID":
        return base64.urlsafe_b64encode(uuid.uuid4().bytes).decode().rstrip("=")
    if name == "AIRFLOW_FERNET_KEY":
        return base64.urlsafe_b64encode(os.urandom(32)).decode()
    # chỉ dùng ký tự hex để mật khẩu an toàn khi nhúng vào chuỗi kết nối URL
    return secrets.token_hex(16)

out = []
for line in open(src, encoding="utf-8"):
    m = re.match(r"^([A-Z0-9_]+)=(CHANGE_ME\S*)\s*$", line)
    out.append(f"{m.group(1)}={gen(m.group(1))}\n" if m else line)

with open(dst, "w", encoding="utf-8") as f:
    f.writelines(out)
os.chmod(dst, 0o600)
print(f"Đã tạo {dst} với bí mật ngẫu nhiên (không hiển thị).")
PY
