#!/usr/bin/env bash
# Kiểm tra sức khỏe toàn bộ hạ tầng sau `docker compose up -d`.
#   Đầu vào : các container đang chạy; conf/.env
#   Đầu ra  : bảng PASS/FAIL trên stdout; mã thoát 0 nếu tất cả PASS, 1 nếu có FAIL.
#             Dùng `bash conf/scripts/check_services.sh | tee docs/evidence/check_services.txt` để lưu bằng chứng.
#   Tuỳ chọn: --smoke  chạy thêm tests/infra/smoke_delta_hdfs.py (ghi/MERGE/time travel/OPTIMIZE trên HDFS)
#                      và tests/infra/smoke_kafka_spark.py (Spark <-> Kafka)
#   Phụ thuộc: docker compose, curl, python3 trên máy chủ.
set -uo pipefail
cd "$(dirname "$0")/../.."

DC="docker compose --env-file conf/.env"
PASS=0; FAIL=0
ok()   { printf '  [PASS] %s\n' "$1"; PASS=$((PASS+1)); }
bad()  { printf '  [FAIL] %s\n' "$1"; FAIL=$((FAIL+1)); }
check() { # check "mô tả" lệnh...
  local desc="$1"; shift
  if "$@" >/dev/null 2>&1; then ok "${desc}"; else bad "${desc}"; fi
}
port() { grep -E "^$1=" conf/.env | head -1 | cut -d= -f2; }

[ -f conf/.env ] || { echo "Thiếu conf/.env — chạy: bash conf/scripts/make_env.sh"; exit 1; }
if grep -q 'CHANGE_ME' conf/.env; then bad "conf/.env còn giá trị CHANGE_ME (chưa sinh bí mật)"; fi

echo "== 1. Container =="
for svc in namenode datanode kafka spark-master spark-worker-1 spark-worker-2 spark-client postgres mailpit airflow-webserver airflow-scheduler; do
  state="$(${DC} ps --format '{{.Health}}|{{.State}}' "${svc}" 2>/dev/null | head -1)"
  case "${state}" in
    healthy\|*|\|running) ok "${svc}: ${state}" ;;
    *) bad "${svc}: '${state:-không chạy}'" ;;
  esac
done
for job in hdfs-init kafka-init airflow-init; do
  code="$(${DC} ps -a --format '{{.ExitCode}}' "${job}" 2>/dev/null | head -1)"
  [ "${code}" = "0" ] && ok "${job}: đã hoàn thành (exit 0)" || bad "${job}: exit '${code:-?}'"
done

echo "== 2. HDFS =="
check "DataNode đăng ký với NameNode" bash -c "${DC} exec -T namenode hdfs dfsadmin -report | grep -q 'Live datanodes (1)'"
tree="$(${DC} exec -T namenode hdfs dfs -ls hdfs://namenode:8020/lakehouse/bd01_dien_luc 2>/dev/null)"
n=0; for d in bronze silver gold features models checkpoints _quarantine; do echo "${tree}" | grep -q "/${d}\$" && n=$((n+1)); done
[ "${n}" = "7" ] && ok "đủ 7 thư mục /lakehouse/bd01_dien_luc" || bad "chỉ thấy ${n}/7 thư mục chuẩn"
echo "  Phiên bản: $(${DC} exec -T namenode hdfs version 2>/dev/null | head -1)"

echo "== 3. Kafka =="
topic="$(grep -E '^KAFKA_TOPIC_METER_READINGS=' conf/.env | cut -d= -f2)"
check "topic ${topic} tồn tại" bash -c "${DC} exec -T kafka kafka-topics --bootstrap-server kafka:29092 --list | grep -qx '${topic}'"
check "produce + consume 1 message" bash -c "echo kiem_tra_$(date +%s) | ${DC} exec -T kafka kafka-console-producer --bootstrap-server kafka:29092 --topic ${topic} >/dev/null 2>&1 && ${DC} exec -T kafka kafka-console-consumer --bootstrap-server kafka:29092 --topic ${topic} --from-beginning --max-messages 1 --timeout-ms 15000 >/dev/null 2>&1"
echo "  Phiên bản: $(${DC} exec -T kafka kafka-topics --version 2>/dev/null | head -1)"

echo "== 4. Spark Standalone =="
mport="$(port PORT_SPARK_MASTER_UI)"; mport="${mport:-8090}"
workers="$(curl -sf "http://127.0.0.1:${mport}/json/" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("aliveworkers",0))' 2>/dev/null)"
[ "${workers:-0}" = "2" ] && ok "2 worker ALIVE" || bad "số worker ALIVE = '${workers:-?}' (cần 2)"
echo "  Phiên bản: $(${DC} exec -T spark-client /opt/spark/bin/spark-submit --version 2>&1 | grep -m1 'version')"
check "import pyspark + delta (Python 3.10) trong spark-client" ${DC} exec -T spark-client python3 -c "import pyspark, delta; print(pyspark.__version__)"
pv_client="$(${DC} exec -T spark-client python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null | tr -d '\r')"
pv_air="$(${DC} exec -T airflow-scheduler python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null | tr -d '\r')"
[ -n "${pv_client}" ] && [ "${pv_client}" = "${pv_air}" ] && ok "Python driver (Airflow) = executor (Spark): ${pv_air}" || bad "Python khác minor: airflow='${pv_air}' spark='${pv_client}'"

echo "== 5. Airflow =="
aport="$(port PORT_AIRFLOW_UI)"; aport="${aport:-8080}"
health="$(curl -sf "http://127.0.0.1:${aport}/health" 2>/dev/null)"
echo "${health}" | grep -q '"metadatabase"' && echo "${health}" | grep -q 'healthy' && ok "webserver /health" || bad "webserver /health"
check "connection spark_default tồn tại" ${DC} exec -T airflow-scheduler airflow connections get spark_default
check "provider apache-spark đã cài" bash -c "${DC} exec -T airflow-scheduler airflow providers list 2>/dev/null | grep -q apache-airflow-providers-apache-spark"
echo "  Phiên bản: Airflow $(${DC} exec -T airflow-scheduler airflow version 2>/dev/null | tail -1)"

if [ "${1:-}" = "--smoke" ]; then
  echo "== 6. Smoke test Delta trên HDFS =="
  if ${DC} exec -T spark-client /opt/spark/bin/spark-submit /opt/bd01/tests/infra/smoke_delta_hdfs.py; then
    ok "smoke_delta_hdfs.py"
  else
    bad "smoke_delta_hdfs.py"
  fi
  echo "== 7. Smoke test Spark <-> Kafka =="
  ${DC} exec -T kafka kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists \
      --topic bd01_smoke_kafka --partitions 1 --replication-factor 1 >/dev/null 2>&1
  if ${DC} exec -T spark-client /opt/spark/bin/spark-submit --total-executor-cores 2 /opt/bd01/tests/infra/smoke_kafka_spark.py; then
    ok "smoke_kafka_spark.py"
  else
    bad "smoke_kafka_spark.py"
  fi
fi

echo
echo "Tổng kết: ${PASS} PASS, ${FAIL} FAIL"
[ "${FAIL}" = "0" ]
