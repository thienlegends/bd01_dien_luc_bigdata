#!/usr/bin/env bash
# Khởi tạo cây thư mục HDFS chuẩn (đề cương mục A.4) cho bd01_dien_luc.
#   Đầu vào : biến LAKEHOUSE_ROOT (mặc định hdfs://namenode:8020/lakehouse/bd01_dien_luc)
#             NameNode đang chạy (service namenode healthy)
#   Đầu ra  : 7 thư mục bronze silver gold features models checkpoints _quarantine
#             + /spark-logs và /user/spark/warehouse (Spark event log / warehouse trên HDFS)
#   Phụ thuộc: image bd01/hadoop, conf/core-site.xml, conf/hdfs-site.xml
#   Idempotent: chạy lại nhiều lần không lỗi, không xóa dữ liệu.
set -euo pipefail

ROOT="${LAKEHOUSE_ROOT:-hdfs://namenode:8020/lakehouse/bd01_dien_luc}"

case "${ROOT}" in
  hdfs://*) ;;
  *) echo "LỖI: LAKEHOUSE_ROOT phải bắt đầu bằng hdfs:// (đang là '${ROOT}'). Không được dùng local filesystem." >&2
     exit 2 ;;
esac

echo "[init_hdfs] Chờ NameNode thoát safe mode..."
hdfs dfsadmin -safemode wait

echo "[init_hdfs] Tạo cây thư mục dưới ${ROOT}"
for d in bronze silver gold features models checkpoints _quarantine; do
  hdfs dfs -mkdir -p "${ROOT}/${d}"
done

echo "[init_hdfs] Tạo thư mục hỗ trợ Spark"
hdfs dfs -mkdir -p hdfs://namenode:8020/spark-logs
hdfs dfs -mkdir -p hdfs://namenode:8020/user/spark/warehouse
hdfs dfs -mkdir -p hdfs://namenode:8020/tmp
hdfs dfs -chmod 1777 hdfs://namenode:8020/tmp

echo "[init_hdfs] Kết quả:"
hdfs dfs -ls "${ROOT}"
echo "[init_hdfs] Xong."
