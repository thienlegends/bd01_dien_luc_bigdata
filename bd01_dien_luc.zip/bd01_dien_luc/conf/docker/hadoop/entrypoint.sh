#!/usr/bin/env bash
# Entrypoint cho image Hadoop.
#   Đầu vào : tham số đầu tiên = vai trò (namenode | datanode | resourcemanager | nodemanager)
#             hoặc một lệnh bất kỳ (vd: hdfs dfs -ls /)
#   Đầu ra  : tiến trình Hadoop chạy foreground (để Docker quản lý log và restart)
#   Phụ thuộc: conf/hdfs-site.xml, conf/core-site.xml (mount vào /opt/hadoop/etc/hadoop/)
set -euo pipefail

NN_DIR="/data/hdfs/namenode"

case "${1:-}" in
  namenode)
    # Chỉ format lần đầu (thư mục chưa có current/VERSION). Format lại sẽ XÓA metadata HDFS.
    if [ ! -f "${NN_DIR}/current/VERSION" ]; then
      echo "[entrypoint] NameNode chưa được format -> format lần đầu (clusterId=bd01)"
      hdfs namenode -format -nonInteractive -clusterId bd01
    else
      echo "[entrypoint] NameNode đã có metadata, bỏ qua bước format"
    fi
    exec hdfs namenode
    ;;
  datanode)
    exec hdfs datanode
    ;;
  resourcemanager)
    exec yarn resourcemanager
    ;;
  nodemanager)
    exec yarn nodemanager
    ;;
  *)
    exec "$@"
    ;;
esac
