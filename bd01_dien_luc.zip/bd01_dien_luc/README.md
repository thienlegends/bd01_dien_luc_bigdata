# bd01_dien_luc — Hệ thống giám sát và dự báo phụ tải điện

Đồ án môn Big Data, Đề tài 1 (mã `bd01_dien_luc`). Tài liệu này hướng dẫn **dựng hạ tầng từ đầu và kiểm tra
từng dịch vụ**. Giai đoạn hiện tại **chỉ gồm cấu hình hạ tầng** (HDFS, Spark, Delta Lake, Kafka, Airflow);
pipeline dữ liệu, mô hình ML và web app chưa được triển khai.

> **Trạng thái trung thực (cập nhật 2026-10-11)**
> - Đã làm: kiểm tra *tĩnh* (cú pháp YAML/XML/bash, biến môi trường, khớp phiên bản, `docker compose config`) —
>   `python3 tests/infra/static_checks.py` → 75/75 PASS.
> - **Chưa làm: chạy thật.** Chưa có container nào được khởi động trong quá trình soạn cấu hình (môi trường soạn
>   không có Docker daemon). Mọi mục V01–V13 trong `docs/VERSION_COMPATIBILITY.md` đang ở trạng thái *chưa kiểm chứng*.
>   Bạn là người chạy thật lần đầu; hãy lưu kết quả vào `docs/evidence/`.

## 1. Kiến trúc hạ tầng (tóm tắt)

```
 máy chủ (Docker)
 ├── HDFS 3.3.6 : namenode + datanode (replication = 1)        <- nơi DUY NHẤT lưu bảng Delta
 │      └── hdfs://namenode:8020/lakehouse/bd01_dien_luc/{bronze,silver,gold,features,models,checkpoints,_quarantine}
 ├── Spark 3.5.1 Standalone : spark-master + 2 worker (mỗi worker = 1 executor 2 core / 2 GB)
 │      └── Delta Lake 3.1.0 = thư viện (jar) nạp qua spark.jars.packages, KHÔNG phải một dịch vụ riêng
 ├── spark-client : container để chạy spark-submit, job streaming, pytest
 ├── Kafka 3.6.x (Confluent 7.6.14, KRaft, 1 node) + topic meter_readings
 └── Airflow 2.9.3 (LocalExecutor) + Postgres 16 + Mailpit (hộp thư giả để nhận email cảnh báo)
```

Thuật ngữ cho người mới: **HDFS** = hệ thống file phân tán (NameNode giữ danh mục file, DataNode giữ dữ liệu);
**Delta Lake** = lớp bảng có giao dịch (ACID) đặt trên file Parquet; **Standalone** = trình quản lý cụm riêng của
Spark (thay cho YARN); **KRaft** = Kafka tự quản lý metadata, không cần ZooKeeper; **client mode** = chương trình
điều khiển (driver) chạy ngay trong container gọi `spark-submit`.

## 2. Yêu cầu máy

| Mục | Yêu cầu | Ghi chú |
|---|---|---|
| Docker | Docker Engine + **Compose v2** (`docker compose version`) | Không dùng `docker-compose` v1 |
| RAM cấp cho Docker | **≥ 12 GB** (máy 16 GB) | Windows: `%UserProfile%\.wslconfig` → `memory=12GB`; macOS: Docker Desktop → Resources. Chi tiết: `docs/MEMORY_BUDGET.md` |
| Đĩa trống | ≥ 15 GB (ước lượng, chưa đo) | image + volume HDFS/Kafka |
| Python 3 trên máy chủ | Python 3 (đã thử trên 3.13) | chỉ để chạy `make_env.sh` và `static_checks.py` (thư viện chuẩn) |
| Mạng | Có Internet lần build/chạy đầu | tải tarball Hadoop, image, gói Maven (Delta, Kafka connector) |

## 3. Cài đặt

```bash
git clone <url-repo> bd01_dien_luc && cd bd01_dien_luc

# 3.1 Sinh conf/.env với bí mật ngẫu nhiên (conf/.env KHÔNG được commit)
bash conf/scripts/make_env.sh

# 3.2 Kiểm tra tĩnh (không cần Docker daemon)
python3 tests/infra/static_checks.py --env conf/.env
```

`conf/.env.example` là bản mẫu an toàn để commit: mọi bí mật là `CHANGE_ME_*`. Không bao giờ điền mật khẩu
thật vào file mẫu. Nếu muốn tự điền: `cp conf/.env.example conf/.env` rồi thay mọi `CHANGE_ME_*`
(`docker compose` sẽ báo lỗi và dừng nếu thiếu biến bắt buộc).

## 4. Build image

```bash
docker compose --env-file conf/.env build
```

Lần đầu mất nhiều thời gian vì tải tarball Hadoop 3.3.6 (có kiểm tra SHA-512) và image Spark/Airflow.
Luôn dùng `--env-file conf/.env` (file `.env` nằm trong `conf/`, đúng cấu trúc chuẩn của đề cương,
nên Compose không tự đọc).

## 5. Khởi động (theo giai đoạn để tiết kiệm RAM)

```bash
# Giai đoạn A (tuần 2): HDFS + Spark + Kafka
docker compose --env-file conf/.env up -d \
  namenode datanode hdfs-init spark-master spark-worker-1 spark-worker-2 spark-client kafka kafka-init

# Giai đoạn B (tuần 4): thêm Airflow (tự kéo theo postgres, airflow-init)
docker compose --env-file conf/.env up -d airflow-webserver airflow-scheduler mailpit
```

Hoặc bật tất cả: `docker compose --env-file conf/.env up -d`.

Profile tuỳ chọn (tắt mặc định):

```bash
# YARN (chỉ khởi động daemon; tích hợp Spark-on-YARN chưa làm ở giai đoạn này)
docker compose --env-file conf/.env --profile yarn up -d resourcemanager nodemanager
# Spark History Server (xem lại số liệu stage/shuffle của job đã chạy xong)
docker compose --env-file conf/.env --profile history up -d spark-history
```

Container một lần (`hdfs-init`, `kafka-init`, `airflow-init`) chạy xong sẽ ở trạng thái `Exited (0)` — bình thường.

## 6. Kiểm tra dịch vụ

```bash
bash conf/scripts/check_services.sh | tee docs/evidence/check_services.txt
```

Script in `[PASS]/[FAIL]` cho: trạng thái container; DataNode đã đăng ký; **đủ 7 thư mục** dưới
`/lakehouse/bd01_dien_luc`; topic `meter_readings`; produce/consume 1 tin nhắn; 2 worker Spark ALIVE;
`import pyspark, delta`; Python của Airflow trùng Python của executor; Airflow `/health`; connection `spark_default`.
Kèm số phiên bản Hadoop/Kafka/Spark/Airflow thực tế (đối chiếu với `docs/VERSION_COMPATIBILITY.md`).

Kiểm tay (lưu làm bằng chứng):

```bash
DC="docker compose --env-file conf/.env"
$DC exec namenode hdfs dfs -ls -R hdfs://namenode:8020/lakehouse/bd01_dien_luc     # đủ 7 thư mục
$DC exec namenode hdfs dfs -du -h hdfs://namenode:8020/lakehouse/bd01_dien_luc     # nộp kèm theo A.6.3
$DC exec namenode hdfs dfsadmin -report | head -20                                  # Live datanodes (1)
$DC exec kafka kafka-topics --version                                               # kỳ vọng 3.6.x
```

## 7. Smoke test: Delta Lake ghi vào HDFS

Chứng minh hạ tầng đủ cho yêu cầu A.6.2/A.6.3 (ghi Delta lên HDFS, MERGE, `DESCRIBE HISTORY`, `VERSION AS OF`,
Change Data Feed, `OPTIMIZE` kèm số file trước/sau). **Không phải pipeline của đề tài.**

```bash
docker compose --env-file conf/.env exec spark-client \
  spark-submit /opt/bd01/tests/infra/smoke_delta_hdfs.py --keep | tee docs/evidence/smoke_delta_hdfs.txt
```

Đạt khi `all_ok: true` và `location` bắt đầu bằng `hdfs://`. Lần đầu sẽ tải gói Maven vào volume Ivy
(vài phút); lần sau log phải ghi `found ... in` thay vì `downloading`.

Kiểm tra *không có bảng Delta nào rơi xuống đĩa local* (không được xuất hiện kết quả):

```bash
for s in spark-client spark-worker-1 spark-worker-2 airflow-scheduler; do
  docker compose --env-file conf/.env exec -T $s sh -c 'find / -xdev -name _delta_log -not -path "/proc/*" 2>/dev/null' ; done
```

## 7b. Smoke test: Spark ↔ Kafka (mục V08)

Chưa có job streaming thật; script này chỉ ghi 1 tin nhắn rồi đọc lại để chứng minh connector
`spark-sql-kafka-0-10_2.12:3.5.1` nói chuyện được với broker 3.6 (không đụng tới topic `meter_readings`):

```bash
DC="docker compose --env-file conf/.env"
$DC exec -T kafka kafka-topics --bootstrap-server kafka:29092 --create --if-not-exists \
    --topic bd01_smoke_kafka --partitions 1 --replication-factor 1
$DC exec spark-client spark-submit --total-executor-cores 2 \
    /opt/bd01/tests/infra/smoke_kafka_spark.py | tee docs/evidence/v08_kafka_source.txt
```

Đạt khi `"all_ok": true`. Lỗi `NoSuchMethodError`/`ClassNotFoundException` nghĩa là sai phiên bản connector.

## 8. Smoke test: Airflow → Spark → Delta → HDFS

1. Mở Airflow UI (cổng ở mục 10), đăng nhập bằng `AIRFLOW_ADMIN_USER` / `AIRFLOW_ADMIN_PASSWORD` trong `conf/.env`.
2. Bật (unpause) DAG `infra_smoke_test`, bấm **Trigger**.
3. Đạt khi task `smoke_delta_hdfs` xanh và log có `"all_ok": true`. Chụp UI + log vào `docs/evidence/`.

DAG này không thuộc các DAG nghiệm thu của đề tài; có thể xóa sau giai đoạn hạ tầng.

## 9. Quy tắc tài nguyên Spark (quan trọng với máy 16 GB)

Cụm chỉ có **4 core = 2 worker × 2 core**. Mặc định một ứng dụng chiếm tối đa 4 core (`spark.cores.max=4`),
nên job streaming chạy liên tục sẽ làm job batch bị đói tài nguyên. Quy ước:

| Loại | Lệnh | Tài nguyên |
|---|---|---|
| Streaming (chạy liên tục) | `spark-submit --total-executor-cores 2 --driver-memory 1g ...` | 1 executor (2 core, 2 GB) |
| Batch / ML | `spark-submit ...` (mặc định) hoặc `--total-executor-cores 2` khi chạy song song streaming | 1–2 executor |

Không chạy huấn luyện ML song song với demo streaming. Nếu `OOMKilled`: xem cách giảm trong `docs/MEMORY_BUDGET.md`.

## 10. Cổng và giao diện (chỉ bind 127.0.0.1)

| Dịch vụ | URL | Biến đổi cổng |
|---|---|---|
| HDFS NameNode | http://localhost:9870 | `PORT_HDFS_NN_UI` |
| HDFS DataNode | http://localhost:9864 | `PORT_HDFS_DN_UI` |
| Spark master | http://localhost:8090 | `PORT_SPARK_MASTER_UI` |
| Spark worker 1 / 2 | http://localhost:8091 / 8092 | `PORT_SPARK_WORKER1_UI` / `..2_UI` |
| Spark driver (khi có job) | http://localhost:4040 | `PORT_SPARK_DRIVER_UI` |
| Spark History (profile) | http://localhost:18080 | `PORT_SPARK_HISTORY_UI` |
| YARN RM (profile) | http://localhost:8088 | `PORT_YARN_RM_UI` |
| Kafka (từ máy chủ) | `localhost:9092`; trong Docker: `kafka:29092` | `PORT_KAFKA_HOST` |
| Airflow | http://localhost:8080 | `PORT_AIRFLOW_UI` |
| Mailpit (email giả) | http://localhost:8025 | `PORT_MAILPIT_UI` |

Giới hạn đã biết: nút tải file trên giao diện NameNode có thể lỗi từ trình duyệt (chuyển hướng tới hostname
`datanode` chỉ phân giải được trong mạng Docker). Dùng `docker compose exec namenode hdfs dfs ...` thay thế.

## 11. Dừng / xóa

```bash
docker compose --env-file conf/.env down        # dừng, GIỮ dữ liệu HDFS/Kafka/Airflow (volume)
docker compose --env-file conf/.env down -v     # XÓA TOÀN BỘ dữ liệu (HDFS, Kafka, Postgres) — không hoàn tác
```

## 12. Xử lý sự cố

| Triệu chứng | Nguyên nhân thường gặp | Cách xử lý |
|---|---|---|
| `required variable ... is missing` | chưa có `conf/.env` | `bash conf/scripts/make_env.sh` |
| `pull access denied for bd01/...` | chưa build | `docker compose --env-file conf/.env build` |
| `Incomplete HDFS URI, no host` / ghi nhầm ra local | thiếu `HADOOP_CONF_DIR` hoặc dùng đường dẫn không có `hdfs://` | luôn dùng `LAKEHOUSE_ROOT`; xem quyết định D3 |
| `Permission denied` trên HDFS | client không chạy với `HADOOP_USER_NAME=hadoop` | chạy qua các container của compose (đã đặt sẵn) |
| Container thoát mã 137 / `OOMKilled=true` | thiếu RAM | `docs/MEMORY_BUDGET.md` mục 3 |
| `Python in worker has different version` | Airflow và Spark khác Python minor | cả hai phải 3.10 (`check_services.sh` mục 4 kiểm tra) |
| `ClassNotFoundException: ...DeltaSparkSessionExtension` | truyền `--packages` ghi đè danh sách gói | bỏ `--packages` (đã khai báo trong `spark-defaults.conf`) |
| Cổng bị chiếm | dịch vụ khác dùng cổng | đổi biến `PORT_*` trong `conf/.env` |

## 13. Bằng chứng cần lưu cho giai đoạn hạ tầng (`docs/evidence/`)

`check_services.txt`, `smoke_delta_hdfs.txt` (hoặc `.json`), `hdfs dfs -ls -R` và `hdfs dfs -du -h`, `docker stats`,
ảnh chụp Airflow `infra_smoke_test` thành công. Mã V01–V13 và tên file bằng chứng: `docs/VERSION_COMPATIBILITY.md` mục 3.

## 14. Bản đồ tài liệu

| File | Nội dung |
|---|---|
| `docs/REPO_STRUCTURE.md` | cây thư mục đầy đủ; nhiệm vụ / đầu vào / đầu ra / phụ thuộc của từng file |
| `docs/TECH_DECISIONS.md` | các quyết định kỹ thuật, phương án đã loại, câu hỏi mở |
| `docs/VERSION_COMPATIBILITY.md` | ma trận tương thích phiên bản + danh mục kiểm chứng V01–V13 |
| `docs/MEMORY_BUDGET.md` | ngân sách RAM cho máy 16 GB |
| `docs/AI_USAGE.md` | khai báo dùng AI (bắt buộc theo A.9) — nhóm cần tự điền cột "đã sửa/kiểm chứng" |
